package it.uniroma3.diadia.comando;

import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.giocatore.Giocatore;

public class ComandoVai implements Comando {

	private String parametro;
	private IO io;
	private final static String NOME = "vai";

	@Override
	public void esegui(Partita partita) {
		Stanza corrente = partita.getStanzaCorrente();
		Stanza prossima = null;
		if(this.parametro == null) {
			io.mostraMessaggio("Dove vuoi andare?");
			io.mostraMessaggio(partita.getStanzaCorrente().getDescrizione());
			return ;
		}			
		prossima = corrente.getStanzaAdiacente(parametro);
		if(prossima == null) {
			io.mostraMessaggio("Direzione inesistente!");
			return ;
		}
		Giocatore giocatore = partita.getGiocatore();
		partita.setStanzaCorrente(prossima);
		giocatore.setCfu(giocatore.getCfu()-1);
		io.mostraMessaggio("Numero cfu residui: " + giocatore.getCfu());
	}
	
	@Override
	public void setParametro(String parametro) {
		this.parametro = parametro;
	}
	
	@Override
	public String getParametro() {
		return this.parametro;
	}
	
	@Override
	public String getNome() {
		return NOME;
	}
	
	@Override
	public void setIo(IO io) {
		this.io = io;
	}
	
}

