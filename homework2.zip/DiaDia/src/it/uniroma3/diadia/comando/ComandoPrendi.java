package it.uniroma3.diadia.comando;

import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.Partita;

public class ComandoPrendi implements Comando {

	private IO io;
	private String attrezzo;
	private static final String NOME = "prendi";

	/* Gli attrezzi presi vengono rimossi dalla stanza e aggiunti alla borsa
	 * */
	@Override
	public void esegui(Partita partita) {
		if(!partita.getStanzaCorrente().hasAttrezzo(this.attrezzo)) {
			if(this.attrezzo == null) {
				this.io.mostraMessaggio("Specifica cosa vuoi prendere!");
				return;
			}
			this.io.mostraMessaggio("Attrezzo " + this.attrezzo + " non presente nella stanza");
			return;
		}
		Attrezzo daPrendere = partita.getStanzaCorrente().getAttrezzo(this.attrezzo);
		boolean attrezzoPreso = partita.getGiocatore().getBorsa().addAttrezzo(daPrendere);
		if (!attrezzoPreso) {
			this.io.mostraMessaggio("Non c'è più spazio per nuovi attrezzi nella borsa");
			return;
		}
		partita.getStanzaCorrente().removeAttrezzo(daPrendere);
		this.io.mostraMessaggio("Attrezzo " + this.attrezzo + " preso!");
	}
	
	@Override
	public void setParametro(String parametro) {
		this.attrezzo = parametro;
	}

	@Override
	public void setIo(IO io) {
		this.io = io;
	}

	@Override
	public String getNome() {
		return NOME;
	}

	@Override
	public String getParametro() {
		return this.attrezzo;
	}
}
