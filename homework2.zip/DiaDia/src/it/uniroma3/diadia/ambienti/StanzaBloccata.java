package it.uniroma3.diadia.ambienti;

public class StanzaBloccata extends Stanza{

	private String nomeAttrezzoPerPassare;
	private String nomeDirezioneBloccata;
	
	public StanzaBloccata(String nome, String nomeAttrezzoPerPassare, String nomeDirezioneBloccata) {
		super(nome);
		this.nomeAttrezzoPerPassare = nomeAttrezzoPerPassare;
		this.nomeDirezioneBloccata = nomeDirezioneBloccata;
	}
	
	@Override
	public Stanza getStanzaAdiacente(String direzione) {
		if(!super.hasAttrezzo(nomeAttrezzoPerPassare) && direzione.equals(this.nomeDirezioneBloccata))
			return this;
		return super.getStanzaAdiacente(direzione);
	}
	
	
}
