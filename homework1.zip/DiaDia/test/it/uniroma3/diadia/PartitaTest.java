package it.uniroma3.diadia;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Before;
import org.junit.jupiter.api.Test;

class PartitaTest {

	private Partita partita;
	
	@Before
	public void setUp() {
		this.partita = new Partita();
	}
	
	@Test
	public void testGetStanzaVincenteNotNull() {
		assertNotNull(this.partita.getStanzaVincente());
	}
	
	public void testVintaSeStanzaCorrenteEVincente() {
		
	}
	
	
}
