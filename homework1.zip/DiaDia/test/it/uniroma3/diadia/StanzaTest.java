package it.uniroma3.diadia;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.ambienti.Stanza;

public class StanzaTest {

	protected Stanza stanza;
	private static final int MAX_ATTREZZI = 10;
	private static final String ATTREZZO = "AttrezzoTest";
	private static final String STANZA = "StanzaTest";
	private static final String STANZA_ADIACENTE = "StanzaAdiacente";
	private static final String NORD = "nord";
	
	@Before
	public void creaStanza() {
		this.stanza = new Stanza(STANZA);
	}
	
	@Test
	
	public void testImpostaStanzaAdiacenteSingola() {
		Stanza adiacente = creaStanzaEImpostaAdiacente(this.stanza, STANZA_ADIACENTE);
		assertEquals(adiacente, this.stanza.getStanzaAdiacente(NORD));
	}
	
	public void testCambiaStanzaAdiacente() {
		creaStanzaEImpostaAdiacente(this.stanza, STANZA_ADIACENTE);
		Stanza nuova = creaStanzaEImpostaAdiacente(this.stanza, "Nuova Adiacente");
		assertEquals(nuova, this.stanza.getStanzaAdiacente(NORD));

	}
	
	public void testImpostaMassimo4Stanze() {
		Stanza adiacente = new Stanza(STANZA_ADIACENTE);
		String[] direzioni = {"nord", "sud", "ovest", "est"};
		for(String direzione: direzioni)
			this.stanza.impostaStanzaAdiacente(direzione, adiacente);
		String direzioneNuova = "sud-ovest";
		Stanza daNonInserire = creaStanzaEImpostaAdiacente(this.stanza, "Da non inserire");
		
		assertNotContains(this.stanza.getDirezioni(), direzioneNuova);
	}
	
	private void assertNotContains(String[] direzioni, String direzioneNuova) {
		boolean contiene = false;
		for(String direzione: direzioni)
			if(direzione != null && direzione.equals(direzioneNuova))
				contiene = true;
		
		assertFalse(contiene);
	}

	public void testGetStanzaAdiacenteNonEsistente() {
		assertNull(this.stanza.getStanzaAdiacente(NORD));
	}
	
	public void testGetStanzaAdiacenteEsistente() {
		Stanza adiacente = creaStanzaEImpostaAdiacente(this.stanza, STANZA_ADIACENTE, NORD);
		assertNotNull(this.stanza.getStanzaAdiacente(NORD));

	}
	
	public void testGetDirezioniVuoto() {
		assertArrayEquals(new String[0], this.stanza.getDirezioni());
	}
	
	public void testHasAttrezzoSingolo() {
		Attrezzo attrezzo = new Attrezzo(ATTREZZO, 1);
		this.stanza.addAttrezzo(attrezzo);
		assertTrue(this.stanza.hasAttrezzo(ATTREZZO));
	}
	
}
